package Pattern1;

public class Star {

	public static void main(String[] args) 
	{
		for(int i=0;i<9;i++)
		{
			for(int j=0;j<9;j++)
			{
				if(i==4||j==4||i==j||i+j==8)
				{
					System.out.print(" * ");
				}
				else
				{
					System.out.print(" ");
				}
			}
			 System.out.println();
		}

	}

}
