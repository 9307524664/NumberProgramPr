package Pattern1;

public class DiamondPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i=0;i<=5;i++)
		{
			for(int j=0;j<5-1;j++)
			{
				System.out.println(" ");
			}
			
			 for(int k=0;k<=i;k++)
			 {
				 System.out.println("* ");
			 }
			 
			  System.out.println();
		}
	}

}
