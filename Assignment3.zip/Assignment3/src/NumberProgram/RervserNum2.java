package NumberProgram;

public class RervserNum2 {

	public static void main(String[] args) 
	{
	    int num=1234;
	    
	    int sum=0;
	    
	 
		int rev = 0;
	    
	    
	    while(num>0)
	    {
	    	int rem=rev%10;
	    	int sum1=rem*10;
	    	num/=10;
	    }
	    
	    System.out.println(sum);

	}

}
