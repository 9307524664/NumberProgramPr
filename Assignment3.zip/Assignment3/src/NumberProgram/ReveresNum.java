package NumberProgram;

public class ReveresNum {

	public static void main(String[] args) 
	{
		int num=5689;
		
		
		while(num!=0)
		{
			int rem=num%10;
			System.out.println(rem);
			num/=10;
		}

	}

}
