package NumberProgram;
import java.util.Scanner;
public class FibionacciSeries {

	public static void main(String[] args) 
	{
	    int a=0, b=1,c;
           
	    Scanner sc=new Scanner(System.in);
	    
	    System.out.println("Enter a Number");
	    
	    int n=sc.nextInt();
	    
	    
	    for(int i=1;i<n;i++)
	    {
	    	System.out.println(a+" ");
	    	
	    	c=a+b;
	    	a=b;
	    	b=c;
	    }
	}

}
