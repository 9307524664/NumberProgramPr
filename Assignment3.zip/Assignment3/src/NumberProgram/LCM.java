package NumberProgram;

public class LCM {

	public static void main(String[] args) 
	{
         int num1=12;
         int num2=13;
         
         
         int large=num1>num2?num1:num2;
         
         for(;;)
         {
        	 if(large%num1==0&&large%num2==0)
        	 {
        		 break;
        	 }
        	  large++;
         }
          System.out.println(large);
	}

}
