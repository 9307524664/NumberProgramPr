package NumberProgram;

public class HCF {

	public static void main(String[] args) 
	{
		int num1=76;
		int num2=36;
		
		
		int least=num1<num2?num1:num2;
		
		while(num1%least==0&&num2%least==0)
		{
			break;
		}
		 least--;
         
		 System.out.println(least);
	}
	

}
