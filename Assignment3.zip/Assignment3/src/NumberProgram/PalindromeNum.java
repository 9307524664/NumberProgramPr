package NumberProgram;

public class PalindromeNum {

	public static void main(String[] args) 
	{
		int num=121;
		int rev=0;
		
		int temp=num;
		
		while(temp!=0)
		{
			int rem=temp%10;
			rev=rev*10+rem;
			temp/=10;
		}
		
		if(rev==num)
		{
			System.out.println("Palindrome Number") ;
		}
		else
		{
			System.out.println("NOT palindrome Number");
		}

	}

}
