package Algorithm;

public class BinarySearch {

	public static void main(String[] args) 
	{
		int a[]= {1,2,3,4,5,6,7,8,9,10};
		
		int start=0;
		int end=a.length-1;
		int mid=(start+end)/2;
		int key=9;
		
		boolean flag=false;
		
		for(int i=0;i<a.length;i++)
		{
			if(key==a[mid])
			{
				flag=true;
				break;
			}
			else if(key>a[mid])
			{
				start=mid+1;
			}
			else if(key<a[mid])
			{
				end=mid-1;
			}
			mid=(start+end)/2;
		}
		 if(flag==true)
		 {
			 System.out.println("Key Found");
		 }
		 else
		 {
			 System.out.println("Key  Not Found");
		 }
	}

}
